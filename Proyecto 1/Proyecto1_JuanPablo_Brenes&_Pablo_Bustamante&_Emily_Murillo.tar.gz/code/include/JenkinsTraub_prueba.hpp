/**
 * Copyright (C) 2017-2018
 * Área Académica de Ingeniería en Computadoras, ITCR, Costa Rica
 *
 * This file is part of the numerical analysis lecture CE3102 at TEC
 *
 * @author Pablo Alvarado
 * @date   18.08.2018
 */

#ifndef ANPI_JENKINS_TRAUB_HPP
#define ANPI_JENKINS_TRAUB_HPP

#include <vector>
#include <type_traits>
#include <iostream>
#include <complex>
#include <cmath>
#include <typeinfo>

#include <boost/type_traits/is_complex.hpp>
#include <boost/math/tools/polynomial.hpp>

namespace anpi {

  namespace bmt=boost::math::tools; // for polynomial

  /**
   * Compute the roots of the given polynomial using the Jenkins-Traub method.
   * @param[in] poly polynomial to be analyzed for roots
   * @param[out] roots all roots found
   * @param[in] start initial point for finding the roots
   * @param[in] polish indicate if polishing is needed or not.
   *
   * @return the number of roots found
   */
  template<class T,class U>
  void jenkinsTraub(const bmt::polynomial<T>& poly,						//Método principal.
                    std::vector<U>& roots) {

	bool llamadaASiMisma = false;										//Parámetros iniciales.
	bool raizFueEncontrada = false;
	T menorRaiz;

	smallestRoot(poly,&menorRaiz,&llamadaASiMisma,&raizFueEncontrada);		//Método que calcula las raíces más pequeñas.

	static_assert(std::is_floating_point<T>::value ||
                  boost::is_complex<T>::value,
                  "T must be floating point or complex");
    static_assert(std::is_floating_point<U>::value ||
                  boost::is_complex<U>::value,
                  "U must be floating point or complex");
  }

  template<class T, class U>
  void JenkinsTraub_Aux(const bmt::polynomial<T>& poly, T& menorRaiz, bool& raizFueEncontrada){
	  /*
	   * Método que realiza la iteración.
	   */
	  std::size_t N = poly.degree();											//Grado del polinomio en cuestión.
	  while(N > 2){
	  			if (!raizFueEncontrada)											//Si la raíz no fue encontrada
	  				//throw anpi::Exception ("El procedimiento ha fallado");
	  				throw std::exception("El procedimiento ha fallado");
	  			else{
	  				if (typeid(menorRaiz) == typeid(std::complex<T>)){						//Si es complejo
						//deflate2(poly,menorRaiz,0,std::numeric_limits::());				//Se deflaciona con complejos.
						N=-2;																//Se le restan dos grados al polinomio.
					}
					else{
						//deflate(poly,menorRaiz,0,std::numeric_limits::());				//Se deflaciona con reales.
						N=-1;
					}
	  			}
	  	}
	  calcularUltimasDosRaices(poly);											//Al finalizar se calculan las raíces por el método tradicional.
  }

  template<class T,class U>
  void smallestRoot(const bmt::polynomial<T>& poly,T& menorRaiz, bool& llamadaASiMismo, bool& raizFueEncontrada){

	  std::size_t limiteSuperiorDeLambda = 400;						//Valores que se utilizan en la función.
	  std::size_t limite = 200;
	  float epsilon = 10*exp(-3);									//Valor de epsilon utilizado.
	  std::size_t lambda = 0;

	  bmt::polynomial<T> HPolinomio0(poly);								//H(0,t).
	  HPolinomio0 = calcularDerivada(HPolinomio0);						//H(0,t) = P'(t).

	  aux_smallestroot(lambda, poly, epsilon, HPolinomio0, false);				//Función a la que se accede de diferentes partes del código.

	  }

  template<class T,class U>
  void bloque2(bmt::polynomial<T>& poly, int& lambda, T& menorRaiz ,bool& llamadaASiMismo, bool& raizFueEncontrada, int& shift){

	  if(lambda > 200){
		  if (llamadaASiMismo == true){
			  raizFueEncontrada = false;
			  JenkinsTraub_Aux(poly,lambda,menorRaiz,llamadaASiMismo,raizFueEncontrada);
		  }
		  else{
			  bmt::polynomial<T> HPolinomio0(poly);								//H(0,t).
			  HPolinomio0 = calcularDerivada(HPolinomio0);						//Necesario para mandarlo aux_smallestroot.
			  if(shift == 0){													//Se calcula por el tipo de shift.
				  float& epsilon = pow(10,-3)/10;								//Se manda el epsilon/10.
				  bmt::polynomial<T>& poly2(poly);
				  for (int i = 0 ; i <= poly.size()-1 ; i++){
					  poly2[i] = poly2[i]+2;									//Se realiza la traslación.
				  }
				  ++shift;														//Se aumenta el número de shifts.
				  aux_smallestroot(lambda,poly,epsilon,menorRaiz,true,false,HPolinomio0,shift);
			  }
			  else if(shift == 1){
				  if(!raizFueEncontrada){
					  float& epsilon = pow(10,-3)/100;
					  bmt::polynomial<T>& poly2(poly);
					  for (int i = 0 ; i <= poly.size()-1 ; i++){
						  poly2[i] = poly2[i]+2;								//Se realiza la traslación en el sentido opuesto.
					  }
					  ++shift;
					  aux_smallestroot(lambda,poly,epsilon,menorRaiz,true,false,HPolinomio0,shift);
				  }
				  else{
					  menorRaiz-=T(2);											//Se devuelve el desfase realizado.
					  JenkinsTraub_Aux(poly,menorRaiz,true);
				  }
			  }
			  else{
				  if(!raizFueEncontrada){
					  raizFueEncontrada = false;
					  JenkinsTraub_Aux(poly,lambda,menorRaiz,llamadaASiMismo,raizFueEncontrada);
				  }
				  else{
					  menorRaiz+=T(2);											//Se devuelve el desfase realizado.
					  JenkinsTraub_Aux(poly,lambda,menorRaiz,true);

				  }
			  }
		  }

	  }
  }

  template<class T,class U>
  T calculadorDeModulosPolinomial(bmt::polynomial<T> poly){
	  /*
	   * Función que obtiene el módulo de un polinomio.
	   */

 	  T acumulador;

 	  for (int i = 0 ; i <= poly.size()-1 ; i++){

 		  acumulador+=poly[0][i]*poly[0][i];	//Cada coeficiente se eleva al cuadrado y se suma.

 	  }

 	  return sqrt(acumulador);					//Se retorna la raíz cuadrada de la suma.

   }

  template<class T,class U>
  T calculadorDeModulosVector(std::vector<T> vector){

	  /*
	   * Función que calcula el módulo de un vector.
	   */

	  T acumulador;

	  for (int i = 0 ; i <= vector.size()-1 ; i++){

		  acumulador+=vector[0][i]*vector[0][i];

	  }

	  return sqrt(acumulador);

  }

  template<class T,class U>
  bmt::polynomial<T> calcularR(const bmt::polynomial<T>& poly, int lambda){

	  calcularDiscriminante(poly,lambda+1)/calcularDiscriminante(poly,lambda);		//Fórmula para calcular el R.

  }

  template<class T,class U>
  bmt::polynomial<T> calcularDelta(const bmt::polynomial<T>& poly, int lambda){

	  bmt::polynomial<T> delta;

	  for (int i = 1 ; i < 5 ; i++){

		  delta+= pow(poly.evaluate(i),-lambda);

	  }

	  return delta;

  }

  template<class T,class U>
  bmt::polynomial<T> calcularDiscriminante(const bmt::polynomial<T>& poly, int lambda){

	  bmt::polynomial<T> Discriminante = (calcularDelta(poly,lambda+2)*calcularDelta(poly,lambda))-(calcularDelta(poly,lambda+1)*calcularDelta(poly,lambda+1));

  }

  template<class T,class U>
  void aux_smallestroot(std::size_t& lambda, const bmt::polynomial<T>& poly, float& epsilon, T&menorRaiz, bool& llamadaASiMismo, bool& raizFueEncontrada, bmt::polynomial<T> HPolinomio0, bool& shift){

	  std::vector<bmt::polynomial<T>> vectorDeHPolinomios (100);
	  vectorDeHPolinomios[0] = HPolinomio0;

	  bmt::polynomial<T> divisor = {{0,1}};

	  for (std::size_t i = lambda ; i < (lambda +3) ; ++i){
	  	vectorDeHPolinomios[i+1] = (vectorDeHPolinomios[i]-((vectorDeHPolinomios[i].evaluate(0))/(poly.evaluate(0)))*poly)/divisor;
	  }

	  lambda+=4;

	  std::size_t k = 1;

	  std::vector<T> vectorDeT (100);

	  T t0;

	  bmt::polynomial<T> delta = calcularDelta(poly, lambda);

	  bmt::polynomial<T> Discriminante = calcularDiscriminante(poly, lambda);

	  bmt::polynomial<T> R = calcularR(poly,lambda);

	  if (std::abs(calcularR(poly,lambda+1)-calcularR(poly,lambda))/calcularR(poly,lambda+1) < epsilon){	//Calcular recurrencia escalar.

		  boost::array<T,2> arregloDeCs;

		  T c = 1;

		  std::vector<T> r_lambda (3);

		  T acumuladorDeFor = T(0);

		  T moduloDeCoeficientesDeHPolinomio = calculadorDeModulosPolinomial(vectorDeHPolinomios[0]);

		  T acumuladorDer_lambda = T(0);

		  T moduloDer_lambda = calculadorDeModulosVector(r_lambda);

		  int i = 0;

		  while( i < 10){								//Calcular los mínimos cuadrados.

			  r_lambda = vectorDeHPolinomios[0][lambda+1]+c*vectorDeHPolinomios[0][lambda]+c*vectorDeHPolinomios[0][lambda-1];

			  c-= 0.1;

			  moduloDer_lambda = calculadorDeModulosVector(r_lambda);

		  }

		  if ((moduloDer_lambda/moduloDeCoeficientesDeHPolinomio)< epsilon){

			  if (k==1){

				  bmt::polynomial<T> polyTemporal = {{1,c,c}};

				  std::vector<T> solucionesCuadratica = calcularUltimasDosRaices(&polyTemporal);

				  t0 = solucionesCuadratica[0];


			  	  }

			  	  else{			//K == 2

			  	  }

		  }

		  else
			  bloque2(poly,lambda,menorRaiz,llamadaASiMismo, raizFueEncontrada, shift);

	  }
	  else{

		  bloque2(poly,lambda,menorRaiz,llamadaASiMismo,raizFueEncontrada,shift);

	  }

	  vectorDeT[0] = t0;

	  std::size_t i = 0;							//Poseidown 1.

	  while( i < 10){

		  T Ti = vectorDeT[i]-(poly.evaluate(i)/calcularDerivada(poly).evaluate(i));

		  vectorDeT[i+1] = Ti;

		  if (std::abs(vectorDeT[i+1]-vectorDeT[i])/std::abs(vectorDeT[i]) < epsilon)

			  raizFueEncontrada = true;

		  ++i;

	  }

	  ++k;

	  menorRaiz = vectorDeT[i+1]-vectorDeT[i]/vectorDeT[i];

	  if(!raizFueEncontrada){

		  epsilon/=10;

		  bloque2(poly, lambda, menorRaiz ,llamadaASiMismo, raizFueEncontrada);

	  }
  }

  template<class T,class U>
  std::vector<T> calcularUltimasDosRaices(const bmt::polynomial<T>& poly){					//Se calcula el valor de las dos últimas raíces.
	T raiz1, raiz2;
	T discriminante = (poly[1]*poly[1])-4*poly[0]*poly[2];							//Se realiza la fórmula de inspección cuadrática.
	raiz1 = (-poly[1]-sqrt(discriminante))/(2*poly[0]);
	raiz2 = (-poly[1]+sqrt(discriminante))/(2*poly[0]);
	std::vector<T> vectorRaices(2);
	vectorRaices[0] = raiz1;
	vectorRaices[1] = raiz2;
  }

  template<class T, class U>
  bmt::polynomial<T> calcularDerivada(bmt::polynomial<T> polinomioADerivar){

	  bmt::polynomial<T> HPolinomio0(polinomioADerivar);
	  for (int unsigned(i) = 1 ; i <= polinomioADerivar.degree() ; i++)		//Cálculo y almacenamiento de la derivada.
		  HPolinomio0[i-1] = HPolinomio0[i]*i;
	  HPolinomio0[HPolinomio0.degree()] = 0;
	  HPolinomio0.normalize();
	  return HPolinomio0;

  }

}

#endif
