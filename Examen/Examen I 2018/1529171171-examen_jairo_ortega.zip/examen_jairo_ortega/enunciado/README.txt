Instituto Tecnológico de Costa Rica
Área Académica de Ingeniería en Computadores
CE-3102 Análisis Numérico para Ingeniería
Prof. Pablo Alvarado Moya
I Semestre 2018
Examen Final

Estos son los archivos que acompañan al enunciado del examen final de
Análisis Numérico para Ingeniería, para el primer semestre 2018.


Problema 1:
  regopt.m
  regresion.dat

Problema 2:
  posfromdist.m
  emisors.dat
  dists.dat
  AlgebraicMultilaterationNorrdine.pdf

Problema 3:
  pca.m
  pcadata.dat
