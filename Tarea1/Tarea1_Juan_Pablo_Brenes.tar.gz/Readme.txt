----------------------------------------------------------------------
Tarea 1						Juan Pablo Brenes Coto

Análisis Numérico para Ingeniería		7 Agosto, 2018
----------------------------------------------------------------------

Instrucciónes de ejecución del script "Tarea_1.m" para GNU/Octave

1. Navegar con la consola de Octave hasta la ubicación del archivo
   Tarea_1.m

2. Cargar el script escribiendo en la consola el nombre del archivo
   "Tarea_1" sin la extensión del archivo.

3. Ejecutar cualquiera de las funciones dentro del archivo
	* anpi_erf(x, c)
	* anpi_quadratic(a, b, c)

Para obtener información sobre cualquiera de las funciones, ejecutar
el comando help <nombre_función>
Ejemplo:
	help anpi_erf
