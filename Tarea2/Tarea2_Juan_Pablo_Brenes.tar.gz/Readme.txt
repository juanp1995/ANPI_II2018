----------------------------------------------------------------------
Tarea 2						Juan Pablo Brenes Coto

Análisis Numérico para Ingeniería		16 Agosto, 2018
----------------------------------------------------------------------

Instrucciónes de ejecución del script "Tarea_2.m" para GNU/Octave

1. Navegar con la consola de Octave hasta la ubicación del archivo
   Tarea_2.m

2. Cargar el script escribiendo en la consola el nombre del archivo
   "Tarea_2" sin la extensión del archivo.

3. Ejecutar la función "derivada(x)" dentro del script, sustituyendo <x>
   por el punto donde desea calcular la derivada.

Para obtener información sobre la función, ejecutar
el comando help <derivada>
Ejemplo:
	help derivada
